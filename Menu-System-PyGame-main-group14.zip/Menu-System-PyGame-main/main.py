from app_class import *
from mainmenu import *

#if __name__ == '__main__':
app = MAIN()
app.main_menu()